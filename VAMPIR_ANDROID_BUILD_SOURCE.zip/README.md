# VAMPIR Android

Official VAMPIR Esports Android beta client for **vampirteam.site**.

## Automatic APK
Every push to `main` starts GitHub Actions and uploads `VAMPIR-Android-Beta.apk` as a workflow artifact.

Package: `site.vampirteam.app`  
Minimum Android: 7.0 (API 24)  
Target SDK: 35
