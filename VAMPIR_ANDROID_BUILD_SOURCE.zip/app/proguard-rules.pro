# VAMPIR app - currently no custom ProGuard rules required.
